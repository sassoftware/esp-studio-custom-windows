# event_logger
## README.md
![Example Image](img/example.png "Example Image") 

This is is a sample README.md file. You can add text and images to this template to describe your project and tell other users how it can be used.
